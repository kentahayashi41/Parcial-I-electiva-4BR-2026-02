using System;
using System.Collections.Generic;

class Program
{
    // Listas para guardar los productos en memoria
    static List<string> nombres = new List<string>();
    static List<decimal> precios = new List<decimal>();
    static List<int> stocks = new List<int>();
    static List<int> unidadesVendidas = new List<int>();

    // Datos de la caja
    static decimal totalCaja = 0;
    static int totalVentas = 0;

    static void Main()
    {
        int opcion;

        do
        {
            Console.Clear();

            ImprimirEncabezado(
                "SISTEMA GESTOR DE VENTAS E INVENTARIO (MINI-POS)"
            );

            Console.WriteLine("1. Registrar nuevo producto en inventario");
            Console.WriteLine("2. Consultar inventario completo");
            Console.WriteLine("3. Registrar una venta");
            Console.WriteLine("4. Ver reporte de caja y estadísticas diarias");
            Console.WriteLine("5. Salir");
            Console.WriteLine("====================================================");

            opcion = LeerEntero("Seleccione una opción (1-5): ", 1, 5);

            switch (opcion)
            {
                case 1:
                    RegistrarProducto();
                    break;

                case 2:
                    ConsultarInventario();
                    break;

                case 3:
                    RegistrarVenta();
                    break;

                case 4:
                    MostrarReporte();
                    break;

                case 5:
                    Console.WriteLine();
                    Console.WriteLine("Gracias por utilizar el sistema.");
                    Console.WriteLine("¡Hasta pronto!");
                    break;
            }

            if (opcion != 5)
            {
                Console.WriteLine();
                Console.WriteLine("Presione ENTER para continuar...");
                Console.ReadLine();
            }

        } while (opcion != 5);
    }

    // ==========================================================
    // 1. LEER ENTERO
    // ==========================================================

    static int LeerEntero(string mensaje, int min, int max)
    {
        int numero;

        while (true)
        {
            Console.Write(mensaje);

            string entrada = Console.ReadLine();

            if (int.TryParse(entrada, out numero))
            {
                if (numero >= min && numero <= max)
                {
                    return numero;
                }
                else
                {
                    Console.WriteLine(
                        "[ERROR] Ingrese un valor entre "
                        + min + " y " + max + "."
                    );
                }
            }
            else
            {
                Console.WriteLine(
                    "[ERROR] Entrada no válida. Debe ingresar un número entero."
                );
            }
        }
    }

    // ==========================================================
    // 2. LEER DECIMAL
    // ==========================================================

    static decimal LeerDecimal(string mensaje, decimal min)
    {
        decimal numero;

        while (true)
        {
            Console.Write(mensaje);

            string entrada = Console.ReadLine();

            if (decimal.TryParse(entrada, out numero))
            {
                if (numero >= min)
                {
                    return numero;
                }
                else
                {
                    Console.WriteLine(
                        "[ERROR] El valor debe ser mayor o igual a "
                        + min
                    );
                }
            }
            else
            {
                Console.WriteLine(
                    "[ERROR] Entrada no válida. Debe ingresar un número decimal."
                );
            }
        }
    }

    // ==========================================================
    // 3. CALCULAR FACTURA
    // ==========================================================

    static decimal CalcularFactura(
        decimal precio,
        int cantidad,
        bool tieneDescuento,
        out decimal montoIva,
        out decimal montoDescuento)
    {
        decimal subtotal = precio * cantidad;

        if (tieneDescuento)
        {
            montoDescuento = subtotal * 0.10m;
        }
        else
        {
            montoDescuento = 0;
        }

        decimal subtotalConDescuento = subtotal - montoDescuento;

        montoIva = subtotalConDescuento * 0.19m;

        decimal total = subtotalConDescuento + montoIva;

        return total;
    }

    // ==========================================================
    // 4. ENCABEZADO
    // ==========================================================

    static void ImprimirEncabezado(string titulo)
    {
        Console.WriteLine("====================================================");
        Console.WriteLine("       " + titulo);
        Console.WriteLine("====================================================");
    }

    // ==========================================================
    // REGISTRAR PRODUCTO
    // ==========================================================

    static void RegistrarProducto()
    {
        Console.Clear();

        ImprimirEncabezado("REGISTRAR NUEVO PRODUCTO");

        string nombre;

        while (true)
        {
            Console.Write("Ingrese el nombre del producto: ");

            nombre = Console.ReadLine();

            if (nombre == null)
            {
                nombre = "";
            }

            nombre = nombre.Trim();

            if (nombre == "")
            {
                Console.WriteLine(
                    "[ERROR] El nombre no puede estar vacío."
                );
            }
            else
            {
                bool existe = false;

                for (int i = 0; i < nombres.Count; i++)
                {
                    if (nombres[i].ToLower() == nombre.ToLower())
                    {
                        existe = true;
                    }
                }

                if (existe)
                {
                    Console.WriteLine(
                        "[ERROR] Ya existe un producto con ese nombre."
                    );
                }
                else
                {
                    break;
                }
            }
        }

        decimal precio = LeerDecimal(
            "Ingrese el precio unitario ($): ",
            0.01m
        );

        int stock = LeerEntero(
            "Ingrese el stock inicial: ",
            0,
            1000000
        );

        nombres.Add(nombre);
        precios.Add(precio);
        stocks.Add(stock);
        unidadesVendidas.Add(0);

        Console.WriteLine();
        Console.WriteLine("[OK] Producto registrado correctamente.");
    }

    // ==========================================================
    // CONSULTAR INVENTARIO
    // ==========================================================

    static void ConsultarInventario()
    {
        Console.Clear();

        ImprimirEncabezado("INVENTARIO COMPLETO");

        if (nombres.Count == 0)
        {
            Console.WriteLine(
                "No hay productos registrados en el inventario."
            );

            return;
        }

        Console.WriteLine(
            "ID    PRODUCTO                       PRECIO        STOCK"
        );

        Console.WriteLine(
            "---------------------------------------------------------"
        );

        for (int i = 0; i < nombres.Count; i++)
        {
            Console.Write(
                (i + 1) + ".    "
            );

            Console.Write(
                nombres[i]
            );

            Console.Write(
                "                       "
            );

            Console.Write(
                precios[i].ToString("C")
            );

            Console.Write(
                "       "
            );

            Console.Write(
                stocks[i]
            );

            if (stocks[i] < 5)
            {
                Console.Write(
                    " [ALERTA: BAJO STOCK]"
                );
            }

            Console.WriteLine();
        }
    }

    // ==========================================================
    // REGISTRAR VENTA
    // ==========================================================

    static void RegistrarVenta()
    {
        Console.Clear();

        ImprimirEncabezado("REGISTRAR VENTA");

        if (nombres.Count == 0)
        {
            Console.WriteLine(
                "[ERROR] No hay productos registrados."
            );

            return;
        }

        Console.WriteLine("Productos disponibles:");
        Console.WriteLine();

        for (int i = 0; i < nombres.Count; i++)
        {
            Console.WriteLine(
                (i + 1)
                + ". "
                + nombres[i]
                + " | Precio: "
                + precios[i].ToString("C")
                + " | Stock: "
                + stocks[i]
            );
        }

        Console.WriteLine();

        int producto = LeerEntero(
            "Seleccione el número del producto: ",
            1,
            nombres.Count
        );

        int indice = producto - 1;

        if (stocks[indice] == 0)
        {
            Console.WriteLine(
                "[ERROR] Este producto no tiene stock disponible."
            );

            return;
        }

        int cantidad;

        while (true)
        {
            cantidad = LeerEntero(
                "Ingrese la cantidad a comprar: ",
                1,
                1000000
            );

            if (cantidad > stocks[indice])
            {
                Console.WriteLine(
                    "[ERROR] Stock insuficiente. Solo quedan "
                    + stocks[indice]
                    + " unidades."
                );
            }
            else
            {
                break;
            }
        }

        bool descuento = LeerDescuento();

        decimal montoIva;
        decimal montoDescuento;

        decimal subtotal = precios[indice] * cantidad;

        decimal total = CalcularFactura(
            precios[indice],
            cantidad,
            descuento,
            out montoIva,
            out montoDescuento
        );

        // Actualizar stock
        stocks[indice] = stocks[indice] - cantidad;

        // Registrar unidades vendidas
        unidadesVendidas[indice] =
            unidadesVendidas[indice] + cantidad;

        // Actualizar caja
        totalCaja = totalCaja + total;

        // Actualizar número de ventas
        totalVentas = totalVentas + 1;

        // Mostrar ticket
        Console.WriteLine();

        ImprimirEncabezado("TICKET DE VENTA");

        Console.WriteLine(
            "Producto:    "
            + nombres[indice]
            + " (x"
            + cantidad
            + ")"
        );

        Console.WriteLine(
            "Subtotal:    "
            + subtotal.ToString("C")
        );

        Console.WriteLine(
            "Descuento:  -"
            + montoDescuento.ToString("C")
        );

        Console.WriteLine(
            "IVA (19%):  +"
            + montoIva.ToString("C")
        );

        Console.WriteLine(
            "----------------------------------------------------"
        );

        Console.WriteLine(
            "TOTAL:       "
            + total.ToString("C")
        );

        Console.WriteLine(
            "===================================================="
        );

        Console.WriteLine(
            "[OK] Venta efectuada con éxito."
        );

        Console.WriteLine(
            "Stock actualizado: "
            + stocks[indice]
            + " unidades."
        );
    }

    // ==========================================================
    // LEER DESCUENTO
    // ==========================================================

    static bool LeerDescuento()
    {
        while (true)
        {
            Console.Write(
                "¿Aplica descuento de cliente frecuente (10%)? (S/N): "
            );

            string respuesta = Console.ReadLine();

            if (respuesta == null)
            {
                respuesta = "";
            }

            respuesta = respuesta.ToUpper();

            if (respuesta == "S")
            {
                return true;
            }

            if (respuesta == "N")
            {
                return false;
            }

            Console.WriteLine(
                "[ERROR] Debe responder S o N."
            );
        }
    }

    // ==========================================================
    // REPORTE
    // ==========================================================

    static void MostrarReporte()
    {
        Console.Clear();

        ImprimirEncabezado(
            "REPORTE DE CAJA Y ESTADÍSTICAS DIARIAS"
        );

        Console.WriteLine(
            "Total de ventas realizadas: "
            + totalVentas
        );

        Console.WriteLine(
            "Total acumulado en caja: "
            + totalCaja.ToString("C")
        );

        decimal promedio = 0;

        if (totalVentas > 0)
        {
            promedio = totalCaja / totalVentas;
        }

        Console.WriteLine(
            "Promedio por venta: "
            + promedio.ToString("C")
        );

        Console.WriteLine();

        if (totalVentas == 0)
        {
            Console.WriteLine(
                "Producto con mayor cantidad de unidades vendidas: Ninguno"
            );

            return;
        }

        int posicionMayor = 0;

        for (int i = 1; i < unidadesVendidas.Count; i++)
        {
            if (
                unidadesVendidas[i]
                > unidadesVendidas[posicionMayor]
            )
            {
                posicionMayor = i;
            }
        }

        if (unidadesVendidas[posicionMayor] > 0)
        {
            Console.WriteLine(
                "Producto con mayor cantidad de unidades vendidas: "
                + nombres[posicionMayor]
            );

            Console.WriteLine(
                "Unidades vendidas: "
                + unidadesVendidas[posicionMayor]
            );
        }
        else
        {
            Console.WriteLine(
                "Producto con mayor cantidad de unidades vendidas: Ninguno"
            );
        }
    }
}
